# Guess Person Game

A fun guessing game to match people with their images.

## Features
- Interactive gameplay using Kivy
- Includes default questions and resources
- Customizable for your own image sets

## Installation
```bash
pip install guess_person_game
